# John A Momodu Nigerian Limited - Website Deployment Guide

## 📦 Package Contents

```
john-amomodu-nigerian-limited-website/
├── index.html          # Main entry point
├── assets/
│   ├── index-*.js      # JavaScript bundle
│   └── index-*.css     # CSS styles
```

---

## 🚀 Deployment Options

### Option 1: Shared Hosting (Recommended for Beginners)

**Providers:** Hostinger, Bluehost, SiteGround, Namecheap

**Steps:**
1. Purchase hosting plan
2. Log in to cPanel
3. Open **File Manager**
4. Navigate to `public_html/` folder
5. Upload all files from `john-amomodu-nigerian-limited-website/`
6. Visit your domain - website should be live!

---

### Option 2: VPS/Cloud Server (Advanced)

**Providers:** AWS, DigitalOcean, Linode, Google Cloud

**Using Nginx:**

```bash
# Install Nginx
sudo apt update
sudo apt install nginx

# Create website directory
sudo mkdir -p /var/www/johnamomodu

# Copy files
sudo cp -r /path/to/john-amomodu-nigerian-limited-website/* /var/www/johnamomodu/

# Set permissions
sudo chown -R www-data:www-data /var/www/johnamomodu

# Create Nginx config
sudo nano /etc/nginx/sites-available/johnamomodu
```

**Nginx Configuration:**
```nginx
server {
    listen 80;
    server_name johnamomodunigerianlimited.com www.johnamomodunigerianlimited.com;
    root /var/www/johnamomodu;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    # Enable gzip compression
    gzip on;
    gzip_types text/plain text/css application/json application/javascript;
}
```

```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/johnamomodu /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

---

### Option 3: Static Hosting (Free Options)

**Netlify:**
1. Go to [netlify.com](https://netlify.com)
2. Drag & drop the `john-amomodu-nigerian-limited-website` folder
3. Get free `.netlify.app` URL or connect custom domain

**Vercel:**
1. Go to [vercel.com](https://vercel.com)
2. Import project from GitHub or drag & drop
3. Deploy instantly

**GitHub Pages:**
1. Create GitHub repository
2. Upload files to `gh-pages` branch
3. Enable GitHub Pages in settings

---

## 🔐 SSL Certificate (HTTPS)

### Using Let's Encrypt (Free)

```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Obtain certificate
sudo certbot --nginx -d johnamomodunigerianlimited.com -d www.johnamomodunigerianlimited.com

# Auto-renewal
sudo certbot renew --dry-run
```

### Using Cloudflare (Free SSL Proxy)

1. Sign up at [cloudflare.com](https://cloudflare.com)
2. Add your domain
3. Update nameservers
4. Enable SSL/TLS encryption

---

## 🌐 Domain Configuration

### DNS Records Required

| Type | Name | Value | TTL |
|------|------|-------|-----|
| A | @ | YOUR_SERVER_IP | 3600 |
| A | www | YOUR_SERVER_IP | 3600 |
| OR | | | |
| CNAME | www | johnamomodunigerianlimited.com | 3600 |

### Where to Add DNS Records

1. Log in to your domain registrar (GoDaddy, Namecheap, etc.)
2. Find **DNS Management** or **Nameservers**
3. Add the records above
4. Wait 24-48 hours for propagation

---

## ⚙️ Environment Variables (Optional)

If you want to customize the website without rebuilding:

Create `config.js` in the root:
```javascript
window.CONFIG = {
  COMPANY_NAME: "John A Momodu Nigerian Limited",
  CONTACT_EMAIL: "info@johnamomodu.com",
  CONTACT_PHONE: "+234 803 123 4567",
  ADDRESS: "Plot 123, Industrial Estate, Apapa, Lagos"
};
```

---

## 🧪 Testing Before Launch

### Checklist:
- [ ] Website loads on your domain
- [ ] All pages display correctly
- [ ] Login/Signup works
- [ ] Dashboard loads after login
- [ ] Contact form works (if implemented)
- [ ] SSL certificate is active (https://)
- [ ] Mobile responsive design works
- [ ] All images load properly

### Test URLs:
```
https://yourdomain.com/           # Home page
https://yourdomain.com/login      # Login page (via Client Portal)
```

---

## 🔧 Troubleshooting

### Issue: Website shows blank page
**Solution:** Check browser console for errors. Ensure all files uploaded correctly.

### Issue: CSS/JS not loading
**Solution:** Check file paths. Assets should be in `/assets/` folder.

### Issue: Login doesn't work
**Solution:** This is a static site - auth is client-side using localStorage. Expected behavior.

### Issue: Custom domain not working
**Solution:** 
1. Check DNS propagation: `dig yourdomain.com`
2. Clear browser cache
3. Wait 24-48 hours

---

## 📞 Support Contacts

For technical support:
- Email: your-it-support@company.com
- Phone: +234 XXX XXX XXXX

---

## 📄 File Structure

```
john-amomodu-nigerian-limited-website/
├── index.html              # Main HTML file
├── assets/
│   ├── index-[hash].js     # React application bundle
│   └── index-[hash].css    # Stylesheet
└── (favicon.ico)           # Add your company logo here
```

---

## 🔄 Updates

To update the website:
1. Download new deployment package
2. Replace files on your server
3. Clear browser cache

---

**Last Updated:** 2024
**Version:** 1.0
**Company:** John A Momodu Nigerian Limited
