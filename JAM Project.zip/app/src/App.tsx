import React, { useEffect, useState } from 'react';
import { AuthProvider, useAuth } from '@/hooks/useAuth';
import { initializeDatabase } from '@/services/database';
import HomePage from '@/pages/HomePage';
import LoginPage from '@/pages/LoginPage';
import SignupPage from '@/pages/SignupPage';
import TrackingPage from '@/pages/TrackingPage';
import Dashboard from '@/pages/Dashboard';
import './App.css';

type AppView = 'home' | 'login' | 'signup' | 'tracking';

// Initialize database on app start
const AppContent: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const [appView, setAppView] = useState<AppView>('home');

  useEffect(() => {
    initializeDatabase();
  }, []);

  if (isAuthenticated) {
    return <Dashboard />;
  }

  switch (appView) {
    case 'home':
      return <HomePage 
        onGetStarted={() => setAppView('login')} 
        onTrackShipment={() => setAppView('tracking')}
      />;
    case 'login':
      return <LoginPage onCreateAccount={() => setAppView('signup')} />;
    case 'signup':
      return <SignupPage onBackToLogin={() => setAppView('login')} />;
    case 'tracking':
      return <TrackingPage onBack={() => setAppView('home')} />;
    default:
      return <HomePage 
        onGetStarted={() => setAppView('login')} 
        onTrackShipment={() => setAppView('tracking')}
      />;
  }
};

const App: React.FC = () => {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
};

export default App;
