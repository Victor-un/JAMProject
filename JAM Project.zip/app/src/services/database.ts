import type { User, Container, ActivityLog } from '@/types';

// Database Keys
const DB_KEYS = {
  USERS: 'logitrack_users',
  CONTAINERS: 'logitrack_containers',
  ACTIVITY_LOGS: 'logitrack_activity_logs',
  CURRENT_USER: 'logitrack_current_user',
};

// Initialize default data
export const initializeDatabase = (): void => {
  // Create default admin user if no users exist
  const users = getUsers();
  if (users.length === 0) {
    const defaultAdmin: User = {
      id: 'admin-001',
      username: 'admin',
      email: 'admin@logitrack.com',
      password: 'admin123',
      role: 'admin',
      name: 'System Administrator',
      createdAt: new Date().toISOString(),
    };
    saveUser(defaultAdmin);

    const defaultOperator: User = {
      id: 'op-001',
      username: 'operator',
      email: 'operator@logitrack.com',
      password: 'operator123',
      role: 'operator',
      name: 'Default Operator',
      createdAt: new Date().toISOString(),
    };
    saveUser(defaultOperator);
  }
};

// User Operations
export const getUsers = (): User[] => {
  const data = localStorage.getItem(DB_KEYS.USERS);
  return data ? JSON.parse(data) : [];
};

export const getUserByUsername = (username: string): User | undefined => {
  const users = getUsers();
  return users.find(u => u.username.toLowerCase() === username.toLowerCase());
};

export const getUserById = (id: string): User | undefined => {
  const users = getUsers();
  return users.find(u => u.id === id);
};

export const getUserByEmail = (email: string): User | undefined => {
  const users = getUsers();
  return users.find(u => u.email.toLowerCase() === email.toLowerCase());
};

export const saveUser = (user: User): void => {
  const users = getUsers();
  const existingIndex = users.findIndex(u => u.id === user.id);
  if (existingIndex >= 0) {
    users[existingIndex] = user;
  } else {
    users.push(user);
  }
  localStorage.setItem(DB_KEYS.USERS, JSON.stringify(users));
};

export const deleteUser = (id: string): void => {
  const users = getUsers().filter(u => u.id !== id);
  localStorage.setItem(DB_KEYS.USERS, JSON.stringify(users));
};

// Container Operations
export const getContainers = (): Container[] => {
  const data = localStorage.getItem(DB_KEYS.CONTAINERS);
  return data ? JSON.parse(data) : [];
};

export const getContainerById = (id: string): Container | undefined => {
  const containers = getContainers();
  return containers.find(c => c.id === id);
};

export const getContainerByNumber = (containerNumber: string): Container | undefined => {
  const containers = getContainers();
  return containers.find(c => c.containerNumber.toUpperCase() === containerNumber.toUpperCase());
};

export const saveContainer = (container: Container): void => {
  const containers = getContainers();
  const existingIndex = containers.findIndex(c => c.id === container.id);
  if (existingIndex >= 0) {
    containers[existingIndex] = container;
  } else {
    containers.push(container);
  }
  localStorage.setItem(DB_KEYS.CONTAINERS, JSON.stringify(containers));
};

export const deleteContainer = (id: string): void => {
  const containers = getContainers().filter(c => c.id !== id);
  localStorage.setItem(DB_KEYS.CONTAINERS, JSON.stringify(containers));
};

// Activity Log Operations
export const getActivityLogs = (): ActivityLog[] => {
  const data = localStorage.getItem(DB_KEYS.ACTIVITY_LOGS);
  return data ? JSON.parse(data) : [];
};

export const getActivityLogsByContainer = (containerId: string): ActivityLog[] => {
  const logs = getActivityLogs();
  return logs.filter(l => l.containerId === containerId).sort((a, b) => 
    new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );
};

export const addActivityLog = (log: ActivityLog): void => {
  const logs = getActivityLogs();
  logs.push(log);
  localStorage.setItem(DB_KEYS.ACTIVITY_LOGS, JSON.stringify(logs));
};

// Current Session Operations
export const setCurrentUser = (user: User | null): void => {
  if (user) {
    localStorage.setItem(DB_KEYS.CURRENT_USER, JSON.stringify(user));
  } else {
    localStorage.removeItem(DB_KEYS.CURRENT_USER);
  }
};

export const getCurrentUser = (): User | null => {
  const data = localStorage.getItem(DB_KEYS.CURRENT_USER);
  return data ? JSON.parse(data) : null;
};

// Statistics
export const getDashboardStats = () => {
  const containers = getContainers();
  const today = new Date().toISOString().split('T')[0];
  
  return {
    totalContainers: containers.length,
    inYard: containers.filter(c => c.status === 'in-yard').length,
    inTransit: containers.filter(c => c.status === 'in-transit').length,
    delivered: containers.filter(c => c.status === 'delivered').length,
    pending: containers.filter(c => c.status === 'pending').length,
    todayEntries: containers.filter(c => c.entryDate.startsWith(today)).length,
    todayExits: containers.filter(c => c.exitDate?.startsWith(today)).length,
  };
};

// Search and Filter
export const searchContainers = (query: string): Container[] => {
  const containers = getContainers();
  const lowerQuery = query.toLowerCase();
  return containers.filter(c => 
    c.containerNumber.toLowerCase().includes(lowerQuery) ||
    c.customerName.toLowerCase().includes(lowerQuery) ||
    c.goodsDescription.toLowerCase().includes(lowerQuery) ||
    c.location.toLowerCase().includes(lowerQuery)
  );
};

export const filterContainersByStatus = (status: string): Container[] => {
  const containers = getContainers();
  if (status === 'all') return containers;
  return containers.filter(c => c.status === status);
};
