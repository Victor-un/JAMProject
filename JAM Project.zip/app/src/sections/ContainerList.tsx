import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Plus, 
  Filter, 
  MoreHorizontal, 
  Eye, 
  Edit, 
  Trash2,
  ArrowUpDown,
  Container,
  Calendar,
  User,
  MapPin
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { getContainers, deleteContainer, searchContainers, filterContainersByStatus, addActivityLog } from '@/services/database';
import { useAuth } from '@/hooks/useAuth';
import type { Container as ContainerType } from '@/types';

interface ContainerListProps {
  limit?: number;
  onContainerClick?: (container: ContainerType) => void;
  onAddContainer?: () => void;
  compact?: boolean;
}

const statusColors: Record<string, string> = {
  'in-yard': 'bg-green-100 text-green-700 border-green-200',
  'in-transit': 'bg-blue-100 text-blue-700 border-blue-200',
  'delivered': 'bg-purple-100 text-purple-700 border-purple-200',
  'pending': 'bg-yellow-100 text-yellow-700 border-yellow-200',
};

const statusLabels: Record<string, string> = {
  'in-yard': 'In Yard',
  'in-transit': 'In Transit',
  'delivered': 'Delivered',
  'pending': 'Pending',
};

const ContainerList: React.FC<ContainerListProps> = ({ 
  limit, 
  onContainerClick, 
  onAddContainer,
  compact = false 
}) => {
  const { user } = useAuth();
  const [containers, setContainers] = useState<ContainerType[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [containerToDelete, setContainerToDelete] = useState<ContainerType | null>(null);
  const [sortField, setSortField] = useState<keyof ContainerType>('createdAt');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');

  useEffect(() => {
    loadContainers();
  }, [searchQuery, statusFilter]);

  const loadContainers = () => {
    let data: ContainerType[];
    
    if (searchQuery) {
      data = searchContainers(searchQuery);
    } else if (statusFilter !== 'all') {
      data = filterContainersByStatus(statusFilter);
    } else {
      data = getContainers();
    }

    // Sort data
    data = data.sort((a, b) => {
      const aValue = a[sortField] ?? '';
      const bValue = b[sortField] ?? '';
      if (sortDirection === 'asc') {
        return aValue > bValue ? 1 : -1;
      }
      return aValue < bValue ? 1 : -1;
    });

    if (limit) {
      data = data.slice(0, limit);
    }

    setContainers(data);
  };

  const handleDelete = (container: ContainerType) => {
    setContainerToDelete(container);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (containerToDelete && user) {
      deleteContainer(containerToDelete.id);
      addActivityLog({
        id: `log-${Date.now()}`,
        containerId: containerToDelete.id,
        action: 'delete',
        performedBy: user.id,
        performedByName: user.name,
        timestamp: new Date().toISOString(),
        details: `Container ${containerToDelete.containerNumber} was deleted`,
      });
      loadContainers();
      setDeleteDialogOpen(false);
      setContainerToDelete(null);
    }
  };

  const handleSort = (field: keyof ContainerType) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
    loadContainers();
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  if (compact) {
    return (
      <div className="space-y-3">
        {containers.length === 0 ? (
          <div className="text-center py-8 text-slate-400">
            <Container className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>No containers found</p>
          </div>
        ) : (
          containers.map((container) => (
            <div 
              key={container.id}
              onClick={() => onContainerClick?.(container)}
              className="flex items-center justify-between p-3 bg-slate-50 rounded-lg hover:bg-slate-100 cursor-pointer transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Container className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="font-medium text-slate-800">{container.containerNumber}</p>
                  <p className="text-sm text-slate-500">{container.customerName}</p>
                </div>
              </div>
              <div className="text-right">
                <Badge variant="outline" className={statusColors[container.status]}>
                  {statusLabels[container.status]}
                </Badge>
                <p className="text-xs text-slate-400 mt-1">{formatDate(container.entryDate)}</p>
              </div>
            </div>
          ))
        )}
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200">
      {/* Header */}
      <div className="p-4 border-b border-slate-200">
        <div className="flex flex-col sm:flex-row gap-4 justify-between">
          <div className="flex gap-2 flex-1">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Search by container #, customer, goods..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="in-yard">In Yard</SelectItem>
                <SelectItem value="in-transit">In Transit</SelectItem>
                <SelectItem value="delivered">Delivered</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={onAddContainer} className="bg-blue-600 hover:bg-blue-700">
            <Plus className="w-4 h-4 mr-2" />
            Add Container
          </Button>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="bg-slate-50">
              <TableHead className="cursor-pointer" onClick={() => handleSort('containerNumber')}>
                <div className="flex items-center gap-1">
                  Container #
                  <ArrowUpDown className="w-3 h-3" />
                </div>
              </TableHead>
              <TableHead>Customer</TableHead>
              <TableHead className="cursor-pointer" onClick={() => handleSort('status')}>
                <div className="flex items-center gap-1">
                  Status
                  <ArrowUpDown className="w-3 h-3" />
                </div>
              </TableHead>
              <TableHead>Size/Type</TableHead>
              <TableHead className="cursor-pointer" onClick={() => handleSort('entryDate')}>
                <div className="flex items-center gap-1">
                  Entry Date
                  <ArrowUpDown className="w-3 h-3" />
                </div>
              </TableHead>
              <TableHead>Location</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {containers.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-12">
                  <Container className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                  <p className="text-slate-500">No containers found</p>
                  <p className="text-sm text-slate-400 mt-1">
                    {searchQuery ? 'Try adjusting your search' : 'Add your first container to get started'}
                  </p>
                </TableCell>
              </TableRow>
            ) : (
              containers.map((container) => (
                <TableRow key={container.id} className="hover:bg-slate-50">
                  <TableCell>
                    <div className="font-medium text-slate-800">{container.containerNumber}</div>
                    <div className="text-sm text-slate-500">{container.goodsDescription}</div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-slate-400" />
                      {container.customerName}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className={statusColors[container.status]}>
                      {statusLabels[container.status]}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <span className="text-sm">{container.size} / {container.type}</span>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-slate-400" />
                      {formatDate(container.entryDate)}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-slate-400" />
                      {container.location}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => onContainerClick?.(container)}>
                          <Eye className="w-4 h-4 mr-2" />
                          View Details
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => onContainerClick?.(container)}>
                          <Edit className="w-4 h-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => handleDelete(container)}
                          className="text-red-600"
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* Delete Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete container <strong>{containerToDelete?.containerNumber}</strong>.
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default ContainerList;
