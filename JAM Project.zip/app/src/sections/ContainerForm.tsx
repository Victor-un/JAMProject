import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, Save, Container as ContainerIcon } from 'lucide-react';
import { saveContainer, addActivityLog, getContainerByNumber } from '@/services/database';
import { useAuth } from '@/hooks/useAuth';
import type { Container as ContainerType, ContainerSize, ContainerType as ContainerTypeEnum, ContainerStatus } from '@/types';
import { v4 as uuidv4 } from 'uuid';

interface ContainerFormProps {
  container?: ContainerType | null;
  onCancel: () => void;
  onSuccess: () => void;
}

const ContainerForm: React.FC<ContainerFormProps> = ({ container, onCancel, onSuccess }) => {
  const { user } = useAuth();
  const isEditing = !!container;

  const [formData, setFormData] = useState<Partial<ContainerType>>({
    containerNumber: '',
    size: '20ft',
    type: 'dry',
    status: 'pending',
    customerName: '',
    customerEmail: '',
    customerPhone: '',
    goodsDescription: '',
    weight: 0,
    entryDate: new Date().toISOString().split('T')[0],
    expectedExitDate: '',
    location: '',
    driverName: '',
    vehicleNumber: '',
    sealNumber: '',
    notes: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (container) {
      setFormData({
        ...container,
        entryDate: container.entryDate.split('T')[0],
        expectedExitDate: container.expectedExitDate?.split('T')[0] || '',
        exitDate: container.exitDate?.split('T')[0] || '',
      });
    }
  }, [container]);

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.containerNumber?.trim()) {
      newErrors.containerNumber = 'Container number is required';
    } else if (!isEditing) {
      const existing = getContainerByNumber(formData.containerNumber);
      if (existing) {
        newErrors.containerNumber = 'Container number already exists';
      }
    }

    if (!formData.customerName?.trim()) {
      newErrors.customerName = 'Customer name is required';
    }

    if (!formData.goodsDescription?.trim()) {
      newErrors.goodsDescription = 'Goods description is required';
    }

    if (!formData.location?.trim()) {
      newErrors.location = 'Location is required';
    }

    if (!formData.weight || formData.weight <= 0) {
      newErrors.weight = 'Valid weight is required';
    }

    if (formData.customerEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.customerEmail)) {
      newErrors.customerEmail = 'Invalid email format';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm() || !user) return;

    setIsSubmitting(true);

    const now = new Date().toISOString();
    const containerData: ContainerType = {
      id: container?.id || uuidv4(),
      containerNumber: formData.containerNumber!.toUpperCase(),
      size: formData.size as ContainerSize,
      type: formData.type as ContainerTypeEnum,
      status: formData.status as ContainerStatus,
      customerName: formData.customerName!,
      customerEmail: formData.customerEmail || '',
      customerPhone: formData.customerPhone || '',
      goodsDescription: formData.goodsDescription!,
      weight: Number(formData.weight),
      entryDate: new Date(formData.entryDate!).toISOString(),
      exitDate: formData.exitDate ? new Date(formData.exitDate).toISOString() : undefined,
      expectedExitDate: formData.expectedExitDate ? new Date(formData.expectedExitDate).toISOString() : undefined,
      location: formData.location!,
      driverName: formData.driverName || '',
      vehicleNumber: formData.vehicleNumber || '',
      sealNumber: formData.sealNumber || '',
      notes: formData.notes || '',
      createdBy: container?.createdBy || user.id,
      createdAt: container?.createdAt || now,
      updatedAt: now,
    };

    saveContainer(containerData);

    // Add activity log
    addActivityLog({
      id: `log-${Date.now()}`,
      containerId: containerData.id,
      action: isEditing ? 'update' : 'entry',
      performedBy: user.id,
      performedByName: user.name,
      timestamp: now,
      details: isEditing 
        ? `Container ${containerData.containerNumber} was updated`
        : `Container ${containerData.containerNumber} was registered`,
    });

    setIsSubmitting(false);
    onSuccess();
  };

  const handleChange = (field: keyof ContainerType, value: any) => {
    setFormData((prev: Partial<ContainerType>) => ({ ...prev, [field]: value }));
    if (errors[field as string]) {
      setErrors(prev => ({ ...prev, [field as string]: '' }));
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="outline" onClick={onCancel}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <h2 className="text-xl font-semibold text-slate-800">
          {isEditing ? 'Edit Container' : 'Add New Container'}
        </h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Basic Information */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <ContainerIcon className="w-5 h-5 text-blue-600" />
              Basic Information
            </CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="containerNumber">Container Number *</Label>
              <Input
                id="containerNumber"
                value={formData.containerNumber}
                onChange={(e) => handleChange('containerNumber', e.target.value)}
                placeholder="e.g., MSKU1234567"
                className={errors.containerNumber ? 'border-red-500' : ''}
                disabled={isEditing}
              />
              {errors.containerNumber && (
                <p className="text-sm text-red-500">{errors.containerNumber}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="size">Container Size *</Label>
              <Select 
                value={formData.size} 
                onValueChange={(value) => handleChange('size', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select size" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="20ft">20 FT</SelectItem>
                  <SelectItem value="40ft">40 FT</SelectItem>
                  <SelectItem value="45ft">45 FT</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="type">Container Type *</Label>
              <Select 
                value={formData.type} 
                onValueChange={(value) => handleChange('type', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="dry">Dry</SelectItem>
                  <SelectItem value="reefer">Reefer</SelectItem>
                  <SelectItem value="open-top">Open Top</SelectItem>
                  <SelectItem value="flat-rack">Flat Rack</SelectItem>
                  <SelectItem value="tank">Tank</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status *</Label>
              <Select 
                value={formData.status} 
                onValueChange={(value) => handleChange('status', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="in-yard">In Yard</SelectItem>
                  <SelectItem value="in-transit">In Transit</SelectItem>
                  <SelectItem value="delivered">Delivered</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="weight">Weight (kg) *</Label>
              <Input
                id="weight"
                type="number"
                value={formData.weight}
                onChange={(e) => handleChange('weight', e.target.value)}
                placeholder="e.g., 25000"
                className={errors.weight ? 'border-red-500' : ''}
              />
              {errors.weight && (
                <p className="text-sm text-red-500">{errors.weight}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="sealNumber">Seal Number</Label>
              <Input
                id="sealNumber"
                value={formData.sealNumber}
                onChange={(e) => handleChange('sealNumber', e.target.value)}
                placeholder="e.g., SL123456"
              />
            </div>
          </CardContent>
        </Card>

        {/* Customer Information */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Customer Information</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="customerName">Customer Name *</Label>
              <Input
                id="customerName"
                value={formData.customerName}
                onChange={(e) => handleChange('customerName', e.target.value)}
                placeholder="e.g., ABC Trading Co."
                className={errors.customerName ? 'border-red-500' : ''}
              />
              {errors.customerName && (
                <p className="text-sm text-red-500">{errors.customerName}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="customerEmail">Email</Label>
              <Input
                id="customerEmail"
                type="email"
                value={formData.customerEmail}
                onChange={(e) => handleChange('customerEmail', e.target.value)}
                placeholder="e.g., contact@abc.com"
                className={errors.customerEmail ? 'border-red-500' : ''}
              />
              {errors.customerEmail && (
                <p className="text-sm text-red-500">{errors.customerEmail}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="customerPhone">Phone</Label>
              <Input
                id="customerPhone"
                value={formData.customerPhone}
                onChange={(e) => handleChange('customerPhone', e.target.value)}
                placeholder="e.g., +1 234 567 8900"
              />
            </div>

            <div className="space-y-2 md:col-span-2 lg:col-span-3">
              <Label htmlFor="goodsDescription">Goods Description *</Label>
              <Textarea
                id="goodsDescription"
                value={formData.goodsDescription}
                onChange={(e) => handleChange('goodsDescription', e.target.value)}
                placeholder="Describe the goods in the container..."
                className={errors.goodsDescription ? 'border-red-500' : ''}
                rows={3}
              />
              {errors.goodsDescription && (
                <p className="text-sm text-red-500">{errors.goodsDescription}</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Dates & Location */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Dates & Location</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="entryDate">Entry Date *</Label>
              <Input
                id="entryDate"
                type="date"
                value={formData.entryDate}
                onChange={(e) => handleChange('entryDate', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="expectedExitDate">Expected Exit Date</Label>
              <Input
                id="expectedExitDate"
                type="date"
                value={formData.expectedExitDate}
                onChange={(e) => handleChange('expectedExitDate', e.target.value)}
              />
            </div>

            {isEditing && (
              <div className="space-y-2">
                <Label htmlFor="exitDate">Actual Exit Date</Label>
                <Input
                  id="exitDate"
                  type="date"
                  value={formData.exitDate}
                  onChange={(e) => handleChange('exitDate', e.target.value)}
                />
              </div>
            )}

            <div className="space-y-2 md:col-span-2 lg:col-span-3">
              <Label htmlFor="location">Current Location *</Label>
              <Input
                id="location"
                value={formData.location}
                onChange={(e) => handleChange('location', e.target.value)}
                placeholder="e.g., Yard A - Section 12"
                className={errors.location ? 'border-red-500' : ''}
              />
              {errors.location && (
                <p className="text-sm text-red-500">{errors.location}</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Transport Information */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Transport Information</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="driverName">Driver Name</Label>
              <Input
                id="driverName"
                value={formData.driverName}
                onChange={(e) => handleChange('driverName', e.target.value)}
                placeholder="e.g., John Smith"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="vehicleNumber">Vehicle Number</Label>
              <Input
                id="vehicleNumber"
                value={formData.vehicleNumber}
                onChange={(e) => handleChange('vehicleNumber', e.target.value)}
                placeholder="e.g., TRK-1234"
              />
            </div>
          </CardContent>
        </Card>

        {/* Notes */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Additional Notes</CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              value={formData.notes}
              onChange={(e) => handleChange('notes', e.target.value)}
              placeholder="Any additional information..."
              rows={4}
            />
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="flex gap-4 justify-end">
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button 
            type="submit" 
            className="bg-blue-600 hover:bg-blue-700"
            disabled={isSubmitting}
          >
            <Save className="w-4 h-4 mr-2" />
            {isSubmitting ? 'Saving...' : (isEditing ? 'Update Container' : 'Save Container')}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default ContainerForm;
