import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { 
  Download, 
  Calendar, 
  TrendingUp, 
  Package,
  Container,
  Clock
} from 'lucide-react';
import { getContainers } from '@/services/database';
import type { Container as ContainerType } from '@/types';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444', '#06b6d4'];

const ReportsSection: React.FC = () => {
  const [containers, setContainers] = useState<ContainerType[]>([]);
  const [timeRange, setTimeRange] = useState('30');

  useEffect(() => {
    const data = getContainers();
    setContainers(data);
  }, []);

  // Status distribution data
  const statusData = [
    { name: 'In Yard', value: containers.filter(c => c.status === 'in-yard').length, color: '#10b981' },
    { name: 'In Transit', value: containers.filter(c => c.status === 'in-transit').length, color: '#3b82f6' },
    { name: 'Delivered', value: containers.filter(c => c.status === 'delivered').length, color: '#8b5cf6' },
    { name: 'Pending', value: containers.filter(c => c.status === 'pending').length, color: '#f59e0b' },
  ].filter(item => item.value > 0);

  // Container type distribution
  const typeDistribution = containers.reduce((acc, container) => {
    acc[container.type] = (acc[container.type] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const typeData = Object.entries(typeDistribution).map(([type, count]) => ({
    name: type.charAt(0).toUpperCase() + type.slice(1),
    value: count,
  }));

  // Size distribution
  const sizeDistribution = containers.reduce((acc, container) => {
    acc[container.size] = (acc[container.size] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const sizeData = Object.entries(sizeDistribution).map(([size, count]) => ({
    name: size,
    value: count,
  }));

  // Daily entries (mock data for last 7 days)
  const getLast7DaysData = () => {
    const data = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      const dayContainers = containers.filter(c => c.entryDate.startsWith(dateStr));
      data.push({
        date: date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }),
        entries: dayContainers.length,
      });
    }
    return data;
  };

  const dailyData = getLast7DaysData();

  // Top customers
  const customerData = containers.reduce((acc, container) => {
    if (!acc[container.customerName]) {
      acc[container.customerName] = { count: 0, weight: 0 };
    }
    acc[container.customerName].count += 1;
    acc[container.customerName].weight += container.weight;
    return acc;
  }, {} as Record<string, { count: number; weight: number }>);

  const topCustomers = Object.entries(customerData)
    .sort((a, b) => b[1].count - a[1].count)
    .slice(0, 5)
    .map(([name, data]) => ({
      name,
      containers: data.count,
      weight: data.weight,
    }));

  const totalWeight = containers.reduce((sum, c) => sum + c.weight, 0);
  const avgWeight = containers.length > 0 ? totalWeight / containers.length : 0;

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-4">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-40">
              <Calendar className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Time Range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">Last 7 Days</SelectItem>
              <SelectItem value="30">Last 30 Days</SelectItem>
              <SelectItem value="90">Last 3 Months</SelectItem>
              <SelectItem value="365">Last Year</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button variant="outline">
          <Download className="w-4 h-4 mr-2" />
          Export Report
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-500">Total Containers</p>
                <p className="text-2xl font-bold text-slate-800">{containers.length}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Container className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-500">Total Weight</p>
                <p className="text-2xl font-bold text-slate-800">{(totalWeight / 1000).toFixed(1)}T</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Package className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-500">Avg Weight</p>
                <p className="text-2xl font-bold text-slate-800">{(avgWeight / 1000).toFixed(1)}T</p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-500">Active Now</p>
                <p className="text-2xl font-bold text-slate-800">
                  {containers.filter(c => c.status === 'in-yard' || c.status === 'in-transit').length}
                </p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <Clock className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Status Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Status Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Daily Entries */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Daily Container Entries</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={dailyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" tick={{ fontSize: 12 }} />
                <YAxis />
                <Tooltip />
                <Bar dataKey="entries" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Container Types */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Container Types</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={typeData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis dataKey="name" type="category" width={80} />
                <Tooltip />
                <Bar dataKey="value" fill="#10b981" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Container Sizes */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Container Sizes</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={sizeData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}`}
                >
                  {sizeData.map((_entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Top Customers */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Top Customers</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Customer</th>
                  <th className="text-center py-3 px-4 text-sm font-medium text-slate-500">Containers</th>
                  <th className="text-right py-3 px-4 text-sm font-medium text-slate-500">Total Weight</th>
                </tr>
              </thead>
              <tbody>
                {topCustomers.length === 0 ? (
                  <tr>
                    <td colSpan={3} className="text-center py-8 text-slate-400">
                      No customer data available
                    </td>
                  </tr>
                ) : (
                  topCustomers.map((customer, index) => (
                    <tr key={index} className="border-b border-slate-100 hover:bg-slate-50">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <Badge variant="outline" className="bg-blue-50 text-blue-700">
                            #{index + 1}
                          </Badge>
                          {customer.name}
                        </div>
                      </td>
                      <td className="text-center py-3 px-4">
                        <Badge className="bg-green-100 text-green-700">{customer.containers}</Badge>
                      </td>
                      <td className="text-right py-3 px-4">
                        {(customer.weight / 1000).toFixed(1)} T
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ReportsSection;
