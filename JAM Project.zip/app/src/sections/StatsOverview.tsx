import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Container, 
  Package, 
  Truck, 
  CheckCircle, 
  Clock, 
  TrendingUp,
  TrendingDown
} from 'lucide-react';
import { getDashboardStats } from '@/services/database';
import type { DashboardStats } from '@/types';

const StatsOverview: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats>({
    totalContainers: 0,
    inYard: 0,
    inTransit: 0,
    delivered: 0,
    pending: 0,
    todayEntries: 0,
    todayExits: 0,
  });

  useEffect(() => {
    const dashboardStats = getDashboardStats();
    setStats(dashboardStats);
  }, []);

  const statCards = [
    {
      title: 'Total Containers',
      value: stats.totalContainers,
      icon: Container,
      color: 'bg-blue-500',
      lightColor: 'bg-blue-50',
      textColor: 'text-blue-600',
      trend: '+12%',
      trendUp: true,
    },
    {
      title: 'In Yard',
      value: stats.inYard,
      icon: Package,
      color: 'bg-green-500',
      lightColor: 'bg-green-50',
      textColor: 'text-green-600',
      trend: '+5%',
      trendUp: true,
    },
    {
      title: 'In Transit',
      value: stats.inTransit,
      icon: Truck,
      color: 'bg-orange-500',
      lightColor: 'bg-orange-50',
      textColor: 'text-orange-600',
      trend: '-2%',
      trendUp: false,
    },
    {
      title: 'Delivered',
      value: stats.delivered,
      icon: CheckCircle,
      color: 'bg-purple-500',
      lightColor: 'bg-purple-50',
      textColor: 'text-purple-600',
      trend: '+8%',
      trendUp: true,
    },
    {
      title: 'Pending',
      value: stats.pending,
      icon: Clock,
      color: 'bg-yellow-500',
      lightColor: 'bg-yellow-50',
      textColor: 'text-yellow-600',
      trend: '+3%',
      trendUp: true,
    },
    {
      title: "Today's Activity",
      value: stats.todayEntries + stats.todayExits,
      icon: TrendingUp,
      color: 'bg-cyan-500',
      lightColor: 'bg-cyan-50',
      textColor: 'text-cyan-600',
      subtitle: `${stats.todayEntries} in / ${stats.todayExits} out`,
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
      {statCards.map((stat, index) => (
        <Card key={index} className="border-0 shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-start justify-between">
              <div className={`${stat.lightColor} p-3 rounded-lg`}>
                <stat.icon className={`w-5 h-5 ${stat.textColor}`} />
              </div>
              {stat.trend && (
                <div className={`flex items-center gap-1 text-xs font-medium ${stat.trendUp ? 'text-green-600' : 'text-red-600'}`}>
                  {stat.trendUp ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                  {stat.trend}
                </div>
              )}
            </div>
            <div className="mt-3">
              <p className="text-sm text-slate-500">{stat.title}</p>
              <p className="text-2xl font-bold text-slate-800">{stat.value}</p>
              {stat.subtitle && (
                <p className="text-xs text-slate-400 mt-1">{stat.subtitle}</p>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default StatsOverview;
