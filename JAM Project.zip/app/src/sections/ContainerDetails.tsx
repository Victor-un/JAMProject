import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  ArrowLeft, 
  Edit, 
  Container, 
  User, 
  Calendar, 
  MapPin, 
  Truck, 
  Weight,
  Box,
  Tag,
  FileText,
  Clock,
  History
} from 'lucide-react';
import { getActivityLogsByContainer } from '@/services/database';
import type { Container as ContainerType, ActivityLog } from '@/types';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

interface ContainerDetailsProps {
  container: ContainerType;
  onBack: () => void;
  onEdit: () => void;
}

const statusColors: Record<string, string> = {
  'in-yard': 'bg-green-100 text-green-700 border-green-200',
  'in-transit': 'bg-blue-100 text-blue-700 border-blue-200',
  'delivered': 'bg-purple-100 text-purple-700 border-purple-200',
  'pending': 'bg-yellow-100 text-yellow-700 border-yellow-200',
};

const statusLabels: Record<string, string> = {
  'in-yard': 'In Yard',
  'in-transit': 'In Transit',
  'delivered': 'Delivered',
  'pending': 'Pending',
};

const ContainerDetails: React.FC<ContainerDetailsProps> = ({ container, onBack, onEdit }) => {
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);

  useEffect(() => {
    const logs = getActivityLogsByContainer(container.id);
    setActivityLogs(logs);
  }, [container.id]);

  const formatDate = (dateString?: string) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const InfoRow = ({ icon: Icon, label, value }: { icon: any, label: string, value: React.ReactNode }) => (
    <div className="flex items-start gap-3 py-3">
      <div className="w-8 h-8 bg-slate-100 rounded-lg flex items-center justify-center flex-shrink-0">
        <Icon className="w-4 h-4 text-slate-500" />
      </div>
      <div>
        <p className="text-sm text-slate-500">{label}</p>
        <p className="font-medium text-slate-800">{value || 'N/A'}</p>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <div>
            <h2 className="text-xl font-semibold text-slate-800">{container.containerNumber}</h2>
            <p className="text-sm text-slate-500">Container Details</p>
          </div>
        </div>
        <Button onClick={onEdit} className="bg-blue-600 hover:bg-blue-700">
          <Edit className="w-4 h-4 mr-2" />
          Edit Container
        </Button>
      </div>

      {/* Status Banner */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-white/20 rounded-xl flex items-center justify-center">
              <Container className="w-8 h-8" />
            </div>
            <div>
              <p className="text-blue-100 text-sm">Current Status</p>
              <p className="text-2xl font-bold">{statusLabels[container.status]}</p>
              <p className="text-blue-100 text-sm mt-1">
                Last updated: {formatDate(container.updatedAt)}
              </p>
            </div>
          </div>
          <Badge className={`${statusColors[container.status]} text-base px-4 py-2`}>
            {container.size} / {container.type}
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Basic Information */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Box className="w-5 h-5 text-blue-600" />
              Basic Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-1">
            <InfoRow icon={Tag} label="Container Number" value={container.containerNumber} />
            <Separator />
            <InfoRow icon={Box} label="Size" value={container.size} />
            <Separator />
            <InfoRow icon={Box} label="Type" value={container.type.charAt(0).toUpperCase() + container.type.slice(1)} />
            <Separator />
            <InfoRow icon={Weight} label="Weight" value={`${container.weight.toLocaleString()} kg`} />
            <Separator />
            <InfoRow icon={Tag} label="Seal Number" value={container.sealNumber} />
          </CardContent>
        </Card>

        {/* Customer Information */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <User className="w-5 h-5 text-blue-600" />
              Customer Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-1">
            <InfoRow icon={User} label="Customer Name" value={container.customerName} />
            <Separator />
            <InfoRow icon={User} label="Email" value={container.customerEmail} />
            <Separator />
            <InfoRow icon={User} label="Phone" value={container.customerPhone} />
            <Separator />
            <div className="py-3">
              <p className="text-sm text-slate-500 mb-2">Goods Description</p>
              <p className="text-slate-800 bg-slate-50 p-3 rounded-lg">{container.goodsDescription}</p>
            </div>
          </CardContent>
        </Card>

        {/* Dates & Location */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Calendar className="w-5 h-5 text-blue-600" />
              Dates & Location
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-1">
            <InfoRow icon={Calendar} label="Entry Date" value={formatDate(container.entryDate)} />
            <Separator />
            <InfoRow icon={Calendar} label="Expected Exit Date" value={formatDate(container.expectedExitDate)} />
            <Separator />
            <InfoRow icon={Calendar} label="Actual Exit Date" value={formatDate(container.exitDate)} />
            <Separator />
            <InfoRow icon={MapPin} label="Current Location" value={container.location} />
          </CardContent>
        </Card>

        {/* Transport Information */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Truck className="w-5 h-5 text-blue-600" />
              Transport Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-1">
            <InfoRow icon={User} label="Driver Name" value={container.driverName} />
            <Separator />
            <InfoRow icon={Truck} label="Vehicle Number" value={container.vehicleNumber} />
          </CardContent>
        </Card>
      </div>

      {/* Notes */}
      {container.notes && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <FileText className="w-5 h-5 text-blue-600" />
              Additional Notes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-slate-700 whitespace-pre-wrap">{container.notes}</p>
          </CardContent>
        </Card>
      )}

      {/* Activity History */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <History className="w-5 h-5 text-blue-600" />
            Activity History
          </CardTitle>
        </CardHeader>
        <CardContent>
          {activityLogs.length === 0 ? (
            <div className="text-center py-8 text-slate-400">
              <Clock className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No activity recorded yet</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date & Time</TableHead>
                  <TableHead>Action</TableHead>
                  <TableHead>Performed By</TableHead>
                  <TableHead>Details</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {activityLogs.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell>{formatDate(log.timestamp)}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="capitalize">
                        {log.action}
                      </Badge>
                    </TableCell>
                    <TableCell>{log.performedByName}</TableCell>
                    <TableCell>{log.details}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ContainerDetails;
