// User Types
export interface User {
  id: string;
  username: string;
  email: string;
  password: string;
  role: 'admin' | 'operator' | 'viewer';
  name: string;
  createdAt: string;
}

// Container Types
export type ContainerStatus = 'in-yard' | 'in-transit' | 'delivered' | 'pending';
export type ContainerSize = '20ft' | '40ft' | '45ft';
export type ContainerType = 'dry' | 'reefer' | 'open-top' | 'flat-rack' | 'tank';

export interface Container {
  id: string;
  containerNumber: string;
  size: ContainerSize;
  type: ContainerType;
  status: ContainerStatus;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  goodsDescription: string;
  weight: number;
  entryDate: string;
  exitDate?: string;
  expectedExitDate?: string;
  location: string;
  driverName?: string;
  vehicleNumber?: string;
  sealNumber?: string;
  notes?: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

// Activity Log
export interface ActivityLog {
  id: string;
  containerId: string;
  action: 'entry' | 'exit' | 'update' | 'delete';
  performedBy: string;
  performedByName: string;
  timestamp: string;
  details: string;
}

// Dashboard Stats
export interface DashboardStats {
  totalContainers: number;
  inYard: number;
  inTransit: number;
  delivered: number;
  pending: number;
  todayEntries: number;
  todayExits: number;
}

// Auth Context
export interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  isAuthenticated: boolean;
}
