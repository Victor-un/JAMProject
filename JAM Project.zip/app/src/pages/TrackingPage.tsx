import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Search, 
  Package, 
  MapPin, 
  Clock, 
  CheckCircle, 
  Truck, 
  Warehouse,
  ArrowLeft,
  Calendar,
  User,
  Weight,
  AlertCircle
} from 'lucide-react';
import { getContainerByNumber } from '@/services/database';
import type { Container } from '@/types';

interface TrackingPageProps {
  onBack: () => void;
}

const TrackingPage: React.FC<TrackingPageProps> = ({ onBack }) => {
  const [trackingNumber, setTrackingNumber] = useState('');
  const [container, setContainer] = useState<Container | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setContainer(null);

    setTimeout(() => {
      const found = getContainerByNumber(trackingNumber);
      if (found) {
        setContainer(found);
      } else {
        setError('Container not found. Please check the tracking number and try again.');
      }
      setLoading(false);
    }, 500);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return <Clock className="w-6 h-6" />;
      case 'in-yard': return <Warehouse className="w-6 h-6" />;
      case 'in-transit': return <Truck className="w-6 h-6" />;
      case 'delivered': return <CheckCircle className="w-6 h-6" />;
      default: return <Package className="w-6 h-6" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-700';
      case 'in-yard': return 'bg-blue-100 text-blue-700';
      case 'in-transit': return 'bg-orange-100 text-orange-700';
      case 'delivered': return 'bg-green-100 text-green-700';
      default: return 'bg-slate-100 text-slate-700';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'pending': return 'Pending';
      case 'in-yard': return 'In Yard';
      case 'in-transit': return 'In Transit';
      case 'delivered': return 'Delivered';
      default: return status;
    }
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const trackingSteps = [
    { status: 'pending', label: 'Booking Confirmed', description: 'Container registered in system' },
    { status: 'in-yard', label: 'Received at Yard', description: 'Container arrived at facility' },
    { status: 'in-transit', label: 'In Transit', description: 'Container is being transported' },
    { status: 'delivered', label: 'Delivered', description: 'Container delivered to destination' },
  ];

  const getCurrentStepIndex = () => {
    return trackingSteps.findIndex(step => step.status === container?.status);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <Package className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="font-bold text-slate-800 text-xs leading-tight">John A Momodu</h1>
                <p className="text-[9px] text-slate-500">Nigerian Limited</p>
              </div>
            </div>
            <Button variant="ghost" onClick={onBack} className="text-slate-600">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="py-12">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h1 className="text-3xl font-bold text-slate-800 mb-3">Track Your Container</h1>
            <p className="text-slate-600">
              Enter your container number to check the current status and location
            </p>
          </div>

          {/* Search Form */}
          <Card className="mb-8">
            <CardContent className="p-6">
              <form onSubmit={handleSearch} className="flex gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <Input
                    placeholder="Enter container number (e.g., MSKU1234567)"
                    value={trackingNumber}
                    onChange={(e) => setTrackingNumber(e.target.value.toUpperCase())}
                    className="pl-10 h-12 text-lg"
                  />
                </div>
                <Button 
                  type="submit" 
                  className="h-12 px-8 bg-blue-600 hover:bg-blue-700"
                  disabled={loading || !trackingNumber.trim()}
                >
                  {loading ? (
                    <span className="animate-spin rounded-full h-5 w-5 border-b-2 border-white" />
                  ) : (
                    'Track'
                  )}
                </Button>
              </form>

              {error && (
                <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                  <p className="text-red-700">{error}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Tracking Results */}
          {container && (
            <div className="space-y-6">
              {/* Status Card */}
              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <p className="text-sm text-slate-500 mb-1">Container Number</p>
                      <h2 className="text-2xl font-bold text-slate-800">{container.containerNumber}</h2>
                    </div>
                    <div className={`px-4 py-2 rounded-full flex items-center gap-2 ${getStatusColor(container.status)}`}>
                      {getStatusIcon(container.status)}
                      <span className="font-semibold">{getStatusLabel(container.status)}</span>
                    </div>
                  </div>

                  {/* Progress Steps */}
                  <div className="relative">
                    <div className="absolute top-5 left-0 right-0 h-1 bg-slate-200">
                      <div 
                        className="h-full bg-blue-600 transition-all duration-500"
                        style={{ width: `${(getCurrentStepIndex() / (trackingSteps.length - 1)) * 100}%` }}
                      />
                    </div>
                    <div className="relative flex justify-between">
                      {trackingSteps.map((step, index) => {
                        const isCompleted = index <= getCurrentStepIndex();
                        const isCurrent = index === getCurrentStepIndex();
                        return (
                          <div key={step.status} className="flex flex-col items-center">
                            <div 
                              className={`w-10 h-10 rounded-full flex items-center justify-center border-4 z-10 ${
                                isCompleted 
                                  ? 'bg-blue-600 border-blue-600 text-white' 
                                  : 'bg-white border-slate-300 text-slate-400'
                              } ${isCurrent ? 'ring-4 ring-blue-200' : ''}`}
                            >
                              {isCompleted ? <CheckCircle className="w-5 h-5" /> : <span className="text-sm">{index + 1}</span>}
                            </div>
                            <p className={`mt-2 text-sm font-medium ${isCompleted ? 'text-slate-800' : 'text-slate-400'}`}>
                              {step.label}
                            </p>
                            <p className="text-xs text-slate-500 text-center max-w-[100px]">{step.description}</p>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Details Grid */}
              <div className="grid md:grid-cols-2 gap-4">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3 mb-2">
                      <User className="w-5 h-5 text-slate-400" />
                      <span className="text-sm text-slate-500">Customer</span>
                    </div>
                    <p className="font-semibold text-slate-800">{container.customerName}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3 mb-2">
                      <Package className="w-5 h-5 text-slate-400" />
                      <span className="text-sm text-slate-500">Goods</span>
                    </div>
                    <p className="font-semibold text-slate-800">{container.goodsDescription}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3 mb-2">
                      <Weight className="w-5 h-5 text-slate-400" />
                      <span className="text-sm text-slate-500">Weight</span>
                    </div>
                    <p className="font-semibold text-slate-800">{container.weight.toLocaleString()} kg</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3 mb-2">
                      <MapPin className="w-5 h-5 text-slate-400" />
                      <span className="text-sm text-slate-500">Current Location</span>
                    </div>
                    <p className="font-semibold text-slate-800">{container.location}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3 mb-2">
                      <Calendar className="w-5 h-5 text-slate-400" />
                      <span className="text-sm text-slate-500">Entry Date</span>
                    </div>
                    <p className="font-semibold text-slate-800">{formatDate(container.entryDate)}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3 mb-2">
                      <Clock className="w-5 h-5 text-slate-400" />
                      <span className="text-sm text-slate-500">Expected Exit</span>
                    </div>
                    <p className="font-semibold text-slate-800">{formatDate(container.expectedExitDate)}</p>
                  </CardContent>
                </Card>
              </div>

              {/* Contact Support */}
              <div className="text-center p-6 bg-blue-50 rounded-xl">
                <p className="text-slate-600 mb-2">Need help with your shipment?</p>
                <p className="text-slate-800 font-semibold">
                  Contact us: info@johnamomodu.com | +234 803 123 4567
                </p>
              </div>
            </div>
          )}

          {/* Demo Info */}
          {!container && !error && (
            <div className="text-center p-8 bg-slate-100 rounded-xl">
              <p className="text-slate-500 mb-4">Demo: Try tracking with these sample container numbers</p>
              <div className="flex flex-wrap justify-center gap-2">
                {['MSKU1234567', 'TGHU7654321', 'APZU9876543'].map(num => (
                  <button
                    key={num}
                    onClick={() => setTrackingNumber(num)}
                    className="px-4 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-700 hover:border-blue-500 hover:text-blue-600"
                  >
                    {num}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-slate-400 text-sm">
            © 2024 John A Momodu Nigerian Limited. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default TrackingPage;
