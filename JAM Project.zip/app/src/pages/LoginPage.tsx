import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useAuth } from '@/hooks/useAuth';
import { Container, Ship, Truck, Package, AlertCircle, UserPlus } from 'lucide-react';

interface LoginPageProps {
  onCreateAccount: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onCreateAccount }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    if (!username || !password) {
      setError('Please enter both username and password');
      setIsLoading(false);
      return;
    }

    try {
      const success = await login(username, password);
      if (!success) {
        setError('Invalid username or password');
      }
    } catch (err) {
      setError('An error occurred during login');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
      {/* Background Pattern */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-10 left-10 opacity-10">
          <Container className="w-32 h-32 text-white" />
        </div>
        <div className="absolute top-20 right-20 opacity-10">
          <Ship className="w-40 h-40 text-white" />
        </div>
        <div className="absolute bottom-20 left-20 opacity-10">
          <Truck className="w-36 h-36 text-white" />
        </div>
        <div className="absolute bottom-10 right-10 opacity-10">
          <Package className="w-28 h-28 text-white" />
        </div>
      </div>

      <div className="w-full max-w-md relative z-10">
        {/* Logo Section */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-white/10 rounded-2xl backdrop-blur-sm mb-4">
            <Container className="w-12 h-12 text-blue-400" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">John A Momodu</h1>
          <h2 className="text-2xl font-bold text-white mb-2">Nigerian Limited</h2>
          <p className="text-blue-200">Container Management System</p>
        </div>

        <Card className="bg-white/95 backdrop-blur-sm shadow-2xl border-0">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-bold text-center text-slate-800">
              Welcome Back
            </CardTitle>
            <CardDescription className="text-center text-slate-500">
              Enter your credentials to access the system
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <Alert variant="destructive" className="bg-red-50 border-red-200">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="username" className="text-slate-700">Username</Label>
                <Input
                  id="username"
                  type="text"
                  placeholder="Enter your username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="h-11 border-slate-300 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-slate-700">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-11 border-slate-300 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>

              <Button
                type="submit"
                className="w-full h-11 bg-blue-600 hover:bg-blue-700 text-white font-semibold"
                disabled={isLoading}
              >
                {isLoading ? (
                  <span className="flex items-center gap-2">
                    <span className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></span>
                    Signing in...
                  </span>
                ) : (
                  'Sign In'
                )}
              </Button>
            </form>

            <div className="mt-6 p-4 bg-slate-50 rounded-lg">
              <p className="text-sm text-slate-600 font-medium mb-2">Demo Credentials:</p>
              <div className="text-sm text-slate-500 space-y-1">
                <p><span className="font-mono bg-slate-200 px-2 py-0.5 rounded">admin</span> / <span className="font-mono bg-slate-200 px-2 py-0.5 rounded">admin123</span> (Administrator)</p>
                <p><span className="font-mono bg-slate-200 px-2 py-0.5 rounded">operator</span> / <span className="font-mono bg-slate-200 px-2 py-0.5 rounded">operator123</span> (Operator)</p>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-200">
              <p className="text-center text-sm text-slate-500">
                Don't have an account?{' '}
                <button
                  type="button"
                  onClick={onCreateAccount}
                  className="inline-flex items-center text-blue-600 hover:text-blue-700 font-medium"
                >
                  <UserPlus className="w-4 h-4 mr-1" />
                  Create Account
                </button>
              </p>
            </div>
          </CardContent>
        </Card>

        <p className="text-center text-blue-200/60 text-sm mt-6">
          © 2024 John A Momodu Nigerian Limited. All rights reserved.
        </p>
      </div>
    </div>
  );
};

export default LoginPage;
