import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Container, 
  Ship, 
  Truck, 
  Train, 
  Plane, 
  Warehouse, 
  Anchor, 
  Globe, 
  Shield, 
  Award, 
  Users, 
  Clock, 
  MapPin, 
  Phone, 
  Mail, 
  Menu, 
  CheckCircle,
  TrendingUp,
  Package,
  ArrowRight
} from 'lucide-react';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Card, CardContent } from '@/components/ui/card';

interface HomePageProps {
  onGetStarted: () => void;
  onTrackShipment?: () => void;
}

const HomePage: React.FC<HomePageProps> = ({ onGetStarted, onTrackShipment }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  const services = [
    {
      icon: Ship,
      title: 'Sea Freight',
      description: 'Full container load (FCL) and less than container load (LCL) shipping services to major ports worldwide.',
      features: ['FCL & LCL Shipping', 'Port-to-Port Delivery', 'Customs Clearance', 'Cargo Insurance']
    },
    {
      icon: Truck,
      title: 'Road Transport',
      description: 'Reliable heavy-duty trucking services for container haulage across Nigeria and West Africa.',
      features: ['Container Haulage', 'Heavy Cargo Transport', 'Cross-Border Logistics', 'Last Mile Delivery']
    },
    {
      icon: Train,
      title: 'Rail Freight',
      description: 'Cost-effective rail transportation solutions for bulk container movements.',
      features: ['Intermodal Transport', 'Bulk Cargo Movement', 'Scheduled Services', 'Warehousing']
    },
    {
      icon: Plane,
      title: 'Air Freight',
      description: 'Express air cargo services for time-sensitive containerized shipments.',
      features: ['Express Delivery', 'Charter Services', 'Door-to-Door', 'Temperature Controlled']
    },
    {
      icon: Warehouse,
      title: 'Warehousing',
      description: 'Secure storage facilities with modern inventory management systems.',
      features: ['Bonded Warehousing', 'Cold Storage', 'Inventory Management', 'Distribution']
    },
    {
      icon: Anchor,
      title: 'Port Services',
      description: 'Comprehensive port handling and stevedoring services at all major Nigerian ports.',
      features: ['Container Handling', 'Stuffing & De-stuffing', 'Cargo Survey', 'Documentation']
    }
  ];

  const stats = [
    { value: '25+', label: 'Years Experience', icon: Clock },
    { value: '50K+', label: 'Containers Moved', icon: Container },
    { value: '100+', label: 'Heavy Duty Trucks', icon: Truck },
    { value: '500+', label: 'Happy Clients', icon: Users },
  ];

  const fleet = [
    { type: 'Flatbed Trailers', count: '40+', capacity: 'Up to 45 tons', image: 'flatbed' },
    { type: 'Container Carriers', count: '60+', capacity: '20ft & 40ft', image: 'carrier' },
    { type: 'Low Bed Trailers', count: '25+', capacity: 'Up to 80 tons', image: 'lowbed' },
    { type: 'Tanker Trucks', count: '15+', capacity: '30,000 liters', image: 'tanker' },
  ];

  const clients = [
    'Dangote Group', 'Nestle Nigeria', 'Unilever', 'PZ Cussons', 
    'Flour Mills of Nigeria', 'Nigerian Breweries', 'MTN Nigeria', 'Shell Nigeria'
  ];

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-md border-b border-slate-200 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <Container className="w-6 h-6 text-white" />
              </div>
              <div className="hidden sm:block">
                <h1 className="font-bold text-slate-800 text-xs leading-tight">John A Momodu</h1>
                <p className="text-[9px] text-slate-500">Nigerian Limited</p>
              </div>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-8">
              <button onClick={() => scrollToSection('home')} className="text-slate-600 hover:text-blue-600 font-medium">Home</button>
              <button onClick={() => scrollToSection('services')} className="text-slate-600 hover:text-blue-600 font-medium">Services</button>
              <button onClick={() => scrollToSection('about')} className="text-slate-600 hover:text-blue-600 font-medium">About</button>
              <button onClick={() => scrollToSection('fleet')} className="text-slate-600 hover:text-blue-600 font-medium">Fleet</button>
              <button onClick={() => scrollToSection('testimonials')} className="text-slate-600 hover:text-blue-600 font-medium">Testimonials</button>
              <button onClick={() => scrollToSection('contact')} className="text-slate-600 hover:text-blue-600 font-medium">Contact</button>
            </div>

            {/* CTA Buttons */}
            <div className="hidden lg:flex items-center gap-3">
              {onTrackShipment && (
                <Button onClick={onTrackShipment} variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50">
                  Track Shipment
                </Button>
              )}
              <Button onClick={onGetStarted} className="bg-blue-600 hover:bg-blue-700">
                Client Portal
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>

            {/* Mobile Menu */}
            <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
              <SheetTrigger asChild className="lg:hidden">
                <Button variant="ghost" size="icon">
                  <Menu className="w-6 h-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-72">
                <div className="flex flex-col h-full">
                  <div className="flex items-center gap-3 mb-8">
                    <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                      <Container className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h1 className="font-bold text-slate-800 text-xs">John A Momodu</h1>
                      <p className="text-[9px] text-slate-500">Nigerian Limited</p>
                    </div>
                  </div>
                  <nav className="flex-1 space-y-4">
                    <button onClick={() => scrollToSection('home')} className="block w-full text-left text-slate-600 hover:text-blue-600 font-medium py-2">Home</button>
                    <button onClick={() => scrollToSection('services')} className="block w-full text-left text-slate-600 hover:text-blue-600 font-medium py-2">Services</button>
                    <button onClick={() => scrollToSection('about')} className="block w-full text-left text-slate-600 hover:text-blue-600 font-medium py-2">About</button>
                    <button onClick={() => scrollToSection('fleet')} className="block w-full text-left text-slate-600 hover:text-blue-600 font-medium py-2">Fleet</button>
                    <button onClick={() => scrollToSection('testimonials')} className="block w-full text-left text-slate-600 hover:text-blue-600 font-medium py-2">Testimonials</button>
                    <button onClick={() => scrollToSection('contact')} className="block w-full text-left text-slate-600 hover:text-blue-600 font-medium py-2">Contact</button>
                  </nav>
                  {onTrackShipment && (
                    <Button onClick={onTrackShipment} variant="outline" className="w-full border-blue-600 text-blue-600 hover:bg-blue-50 mt-4">
                      Track Shipment
                    </Button>
                  )}
                  <Button onClick={onGetStarted} className="w-full bg-blue-600 hover:bg-blue-700 mt-2">
                    Client Portal
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex items-center pt-20">
        {/* Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
          <div className="absolute inset-0 opacity-20">
            <div className="absolute top-20 left-10">
              <Ship className="w-64 h-64 text-white" />
            </div>
            <div className="absolute bottom-20 right-10">
              <Truck className="w-56 h-56 text-white" />
            </div>
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
              <Container className="w-96 h-96 text-white opacity-10" />
            </div>
          </div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 bg-blue-500/20 border border-blue-400/30 rounded-full px-4 py-2 mb-6">
                <Award className="w-4 h-4 text-blue-300" />
                <span className="text-blue-200 text-sm">Nigeria's Leading Logistics Provider</span>
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
                Heavy Duty<br />
                <span className="text-blue-400">Container Transport</span><br />
                Solutions
              </h1>
              <p className="text-lg text-blue-100 mb-8 max-w-xl">
                John A Momodu Nigerian Limited provides world-class container transportation, 
                warehousing, and logistics services across Nigeria and West Africa.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button onClick={onGetStarted} size="lg" className="bg-blue-600 hover:bg-blue-700 text-white px-8">
                  Access Client Portal
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
                {onTrackShipment && (
                  <Button onClick={onTrackShipment} size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                    Track Shipment
                  </Button>
                )}
                <Button onClick={() => scrollToSection('services')} size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                  Our Services
                </Button>
              </div>
            </div>
            <div className="hidden lg:block">
              <div className="relative">
                <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
                  <div className="grid grid-cols-2 gap-6">
                    {stats.slice(0, 4).map((stat, index) => (
                      <div key={index} className="text-center">
                        <stat.icon className="w-8 h-8 text-blue-400 mx-auto mb-2" />
                        <p className="text-3xl font-bold text-white">{stat.value}</p>
                        <p className="text-sm text-blue-200">{stat.label}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <p className="text-4xl lg:text-5xl font-bold text-white mb-2">{stat.value}</p>
                <p className="text-blue-100">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <p className="text-blue-600 font-semibold mb-2">OUR SERVICES</p>
            <h2 className="text-3xl lg:text-4xl font-bold text-slate-800 mb-4">
              Comprehensive Transport Solutions
            </h2>
            <p className="text-slate-600 max-w-2xl mx-auto">
              We offer end-to-end logistics services tailored to meet your container 
              transportation needs across Nigeria and beyond.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="group hover:shadow-xl transition-all duration-300 border-0 shadow-md">
                <CardContent className="p-6">
                  <div className="w-14 h-14 bg-blue-100 rounded-xl flex items-center justify-center mb-4 group-hover:bg-blue-600 transition-colors">
                    <service.icon className="w-7 h-7 text-blue-600 group-hover:text-white transition-colors" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-800 mb-3">{service.title}</h3>
                  <p className="text-slate-600 mb-4">{service.description}</p>
                  <ul className="space-y-2">
                    {service.features.map((feature, fIndex) => (
                      <li key={fIndex} className="flex items-center gap-2 text-sm text-slate-500">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <p className="text-blue-600 font-semibold mb-2">ABOUT US</p>
              <h2 className="text-3xl lg:text-4xl font-bold text-slate-800 mb-6">
                Nigeria's Trusted Name in Container Logistics
              </h2>
              <p className="text-slate-600 mb-6">
                Founded over 25 years ago, John A Momodu Nigerian Limited has grown to become 
                one of Nigeria's most reliable container transport and logistics companies. 
                We specialize in heavy-duty transportation, offering seamless solutions for 
                businesses of all sizes.
              </p>
              <p className="text-slate-600 mb-8">
                Our modern fleet, experienced team, and commitment to excellence have made us 
                the preferred logistics partner for leading multinational corporations and 
                local businesses across Nigeria.
              </p>
              
              <div className="grid sm:grid-cols-2 gap-6">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Shield className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-800">Safety First</h4>
                    <p className="text-sm text-slate-500">Zero compromise on safety standards</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Clock className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-800">On-Time Delivery</h4>
                    <p className="text-sm text-slate-500">99% on-time delivery record</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Globe className="w-5 h-5 text-purple-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-800">Nationwide Coverage</h4>
                    <p className="text-sm text-slate-500">All 36 states + FCT</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <TrendingUp className="w-5 h-5 text-orange-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-800">Track Record</h4>
                    <p className="text-sm text-slate-500">50,000+ containers moved</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              {/* Vision Card */}
              <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl p-8 text-white">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
                    <Globe className="w-6 h-6" />
                  </div>
                  <h3 className="text-2xl font-bold">Our Vision</h3>
                </div>
                <p className="text-blue-100 leading-relaxed">
                  To be the leading integrated logistics and container transport company in 
                  West Africa, recognized for excellence, reliability, and innovation in 
                  delivering world-class supply chain solutions that drive economic growth 
                  across the region.
                </p>
              </div>

              {/* Mission Card */}
              <div className="bg-slate-800 rounded-2xl p-8 text-white">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
                    <Package className="w-6 h-6" />
                  </div>
                  <h3 className="text-2xl font-bold">Our Mission</h3>
                </div>
                <p className="text-slate-300 leading-relaxed">
                  To provide safe, efficient, and cost-effective container transport and logistics 
                  services that exceed customer expectations. We are committed to leveraging 
                  technology, investing in our people, and maintaining the highest standards 
                  of professionalism in all our operations.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Quality Policy Section */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-3xl shadow-xl overflow-hidden">
            <div className="grid lg:grid-cols-2">
              <div className="p-8 lg:p-12">
                <p className="text-blue-600 font-semibold mb-2">QUALITY ASSURANCE</p>
                <h2 className="text-3xl font-bold text-slate-800 mb-6">Our Quality Policy</h2>
                <p className="text-slate-600 mb-8">
                  At John A Momodu Nigerian Limited, quality is not just a goal—it's our standard. 
                  We are committed to continuous improvement and excellence in every aspect of our operations.
                </p>
                
                <div className="space-y-4">
                  {[
                    'Compliance with international safety and quality standards',
                    'Regular maintenance and inspection of all fleet vehicles',
                    'Continuous training and development of our workforce',
                    'Implementation of ISO 9001:2015 quality management systems',
                    'Customer satisfaction measurement and feedback integration',
                    'Environmental responsibility in all our operations'
                  ].map((item, index) => (
                    <div key={index} className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                      <p className="text-slate-700">{item}</p>
                    </div>
                  ))}
                </div>
              </div>
              <div className="bg-gradient-to-br from-blue-600 to-blue-800 p-8 lg:p-12 flex items-center">
                <div className="text-white">
                  <Award className="w-16 h-16 mb-6" />
                  <h3 className="text-2xl font-bold mb-4">Certifications</h3>
                  <ul className="space-y-3 text-blue-100">
                    <li>• ISO 9001:2015 Certified</li>
                    <li>• NARTO Registered Member</li>
                    <li>• Council for Regulation of Freight Forwarding</li>
                    <li>• Nigerian Shippers' Council Licensed</li>
                    <li>• Federal Road Safety Corps Certified</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Fleet Section */}
      <section id="fleet" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <p className="text-blue-600 font-semibold mb-2">OUR FLEET</p>
            <h2 className="text-3xl lg:text-4xl font-bold text-slate-800 mb-4">
              Modern Heavy-Duty Equipment
            </h2>
            <p className="text-slate-600 max-w-2xl mx-auto">
              Our diverse fleet of over 100 heavy-duty vehicles is equipped to handle 
              any container transport challenge.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {fleet.map((item, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6 text-center">
                  <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Truck className="w-8 h-8 text-blue-600" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-800 mb-1">{item.type}</h3>
                  <p className="text-2xl font-bold text-blue-600 mb-1">{item.count}</p>
                  <p className="text-sm text-slate-500">{item.capacity}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Clients Section */}
      <section className="py-16 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <p className="text-blue-600 font-semibold mb-2">TRUSTED BY</p>
            <h2 className="text-2xl lg:text-3xl font-bold text-slate-800">
              Leading Companies Choose Us
            </h2>
          </div>
          <div className="flex flex-wrap justify-center gap-8 lg:gap-12">
            {clients.map((client, index) => (
              <div key={index} className="bg-white px-6 py-4 rounded-lg shadow-sm">
                <p className="font-semibold text-slate-700">{client}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <p className="text-blue-600 font-semibold mb-2">TESTIMONIALS</p>
            <h2 className="text-3xl lg:text-4xl font-bold text-slate-800 mb-4">
              What Our Clients Say
            </h2>
            <p className="text-slate-600 max-w-2xl mx-auto">
              Don't just take our word for it - hear from some of our satisfied clients
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                name: 'Aliko Dangote',
                company: 'Dangote Group',
                quote: 'John A Momodu Nigerian Limited has been our trusted logistics partner for over 10 years. Their reliability and professionalism are unmatched.',
                rating: 5
              },
              {
                name: 'Mrs. Ngozi Okonjo',
                company: 'Nestle Nigeria',
                quote: 'Their container tracking system gives us peace of mind. We always know where our shipments are in real-time.',
                rating: 5
              },
              {
                name: 'Chief Emeka Okafor',
                company: 'Okafor Imports Ltd',
                quote: 'Excellent service from port to warehouse. Their team handles our cargo with utmost care and efficiency.',
                rating: 5
              },
              {
                name: 'Dr. Amina Bello',
                company: 'Bello Trading Co.',
                quote: 'Fast, reliable, and cost-effective. They have helped us streamline our supply chain operations significantly.',
                rating: 5
              },
              {
                name: 'Engr. Tunde Bakare',
                company: 'Bakare Construction',
                quote: 'Their heavy-duty equipment transport is top-notch. We trust them with our most valuable machinery.',
                rating: 5
              },
              {
                name: 'Mrs. Funke Adeyemi',
                company: 'Adeyemi Exports',
                quote: 'Outstanding customer service. They go above and beyond to ensure our shipments arrive on time.',
                rating: 5
              }
            ].map((testimonial, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <div className="flex gap-1 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <span key={i} className="text-yellow-400">★</span>
                    ))}
                  </div>
                  <p className="text-slate-600 mb-6 italic">"{testimonial.quote}"</p>
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-blue-600 font-bold">{testimonial.name.charAt(0)}</span>
                    </div>
                    <div>
                      <p className="font-semibold text-slate-800">{testimonial.name}</p>
                      <p className="text-sm text-slate-500">{testimonial.company}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <p className="text-blue-600 font-semibold mb-2">FAQ</p>
            <h2 className="text-3xl lg:text-4xl font-bold text-slate-800 mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-slate-600">
              Find answers to common questions about our services
            </p>
          </div>

          <div className="space-y-4">
            {[
              {
                question: 'What areas do you operate in?',
                answer: 'We operate across all 36 states in Nigeria plus the FCT. We also provide cross-border services to neighboring West African countries including Benin, Togo, Ghana, and Niger.'
              },
              {
                question: 'How can I track my container?',
                answer: 'You can track your container in real-time through our online tracking system. Simply enter your container number on our Track Shipment page or log into the Client Portal for detailed tracking information.'
              },
              {
                question: 'What types of containers do you handle?',
                answer: 'We handle all standard container types including 20ft, 40ft, and 45ft containers. We also specialize in refrigerated (reefer), open-top, flat-rack, and tank containers.'
              },
              {
                question: 'Do you provide customs clearance services?',
                answer: 'Yes, we offer comprehensive customs clearance services. Our experienced team handles all documentation and regulatory requirements to ensure smooth import/export processes.'
              },
              {
                question: 'What is your delivery timeframe?',
                answer: 'Delivery times vary based on distance and service type. Local deliveries within Lagos typically take 24-48 hours, while interstate deliveries range from 2-7 days depending on the destination.'
              },
              {
                question: 'How do I get a quote for your services?',
                answer: 'You can request a quote by filling out the contact form on our website, calling our office at +234 803 123 4567, or sending an email to info@johnamomodu.com. We typically respond within 24 hours.'
              },
              {
                question: 'Are my goods insured during transport?',
                answer: 'Yes, we offer comprehensive cargo insurance options for all shipments. Basic coverage is included, and additional coverage can be arranged based on your cargo value and requirements.'
              },
              {
                question: 'What payment methods do you accept?',
                answer: 'We accept bank transfers, corporate checks, and cash payments. For regular clients, we also offer credit facilities with agreed payment terms.'
              }
            ].map((faq, index) => (
              <div key={index} className="bg-white rounded-lg shadow-sm overflow-hidden">
                <button
                  onClick={() => setActiveFaq(activeFaq === index ? null : index)}
                  className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-slate-50"
                >
                  <span className="font-semibold text-slate-800">{faq.question}</span>
                  <span className="text-2xl text-slate-400">{activeFaq === index ? '−' : '+'}</span>
                </button>
                {activeFaq === index && (
                  <div className="px-6 pb-4">
                    <p className="text-slate-600">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <p className="text-blue-400 font-semibold mb-2">CONTACT US</p>
              <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">
                Get in Touch
              </h2>
              <p className="text-slate-400 mb-8">
                Ready to streamline your container logistics? Contact us today for a 
                customized quote or to learn more about our services.
              </p>

              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-blue-600/20 rounded-lg flex items-center justify-center">
                    <MapPin className="w-6 h-6 text-blue-400" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-white mb-1">Head Office</h4>
                    <p className="text-slate-400">Plot 123, Industrial Estate,<br />Apapa, Lagos, Nigeria</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-blue-600/20 rounded-lg flex items-center justify-center">
                    <Phone className="w-6 h-6 text-blue-400" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-white mb-1">Phone</h4>
                    <p className="text-slate-400">+234 803 123 4567<br />+234 809 876 5432</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-blue-600/20 rounded-lg flex items-center justify-center">
                    <Mail className="w-6 h-6 text-blue-400" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-white mb-1">Email</h4>
                    <p className="text-slate-400">info@johnamomodu.com<br />operations@johnamomodu.com</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-8">
              <h3 className="text-xl font-bold text-slate-800 mb-6">Request a Quote</h3>
              <form className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-slate-700">Full Name</Label>
                    <Input placeholder="Your name" className="mt-1" />
                  </div>
                  <div>
                    <Label className="text-slate-700">Company</Label>
                    <Input placeholder="Company name" className="mt-1" />
                  </div>
                </div>
                <div>
                  <Label className="text-slate-700">Email</Label>
                  <Input type="email" placeholder="your@email.com" className="mt-1" />
                </div>
                <div>
                  <Label className="text-slate-700">Phone</Label>
                  <Input placeholder="+234..." className="mt-1" />
                </div>
                <div>
                  <Label className="text-slate-700">Service Required</Label>
                  <select className="w-full h-10 px-3 mt-1 rounded-md border border-slate-300 bg-white text-sm">
                    <option>Container Haulage</option>
                    <option>Sea Freight</option>
                    <option>Warehousing</option>
                    <option>Other</option>
                  </select>
                </div>
                <div>
                  <Label className="text-slate-700">Message</Label>
                  <textarea 
                    className="w-full h-24 px-3 py-2 mt-1 rounded-md border border-slate-300 bg-white text-sm resize-none"
                    placeholder="Tell us about your requirements..."
                  />
                </div>
                <Button className="w-full bg-blue-600 hover:bg-blue-700">
                  Submit Request
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-950 py-12 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                  <Container className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="font-bold text-white text-xs">John A Momodu</h4>
                  <p className="text-[9px] text-slate-400">Nigerian Limited</p>
                </div>
              </div>
              <p className="text-slate-400 text-sm">
                Your trusted partner for container transport and logistics solutions in Nigeria.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm text-slate-400">
                <li><button onClick={() => scrollToSection('home')} className="hover:text-blue-400">Home</button></li>
                <li><button onClick={() => scrollToSection('services')} className="hover:text-blue-400">Services</button></li>
                <li><button onClick={() => scrollToSection('about')} className="hover:text-blue-400">About Us</button></li>
                <li><button onClick={() => scrollToSection('testimonials')} className="hover:text-blue-400">Testimonials</button></li>
                {onTrackShipment && (
                  <li><button onClick={onTrackShipment} className="hover:text-blue-400">Track Shipment</button></li>
                )}
                <li><button onClick={() => scrollToSection('contact')} className="hover:text-blue-400">Contact</button></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Services</h4>
              <ul className="space-y-2 text-sm text-slate-400">
                <li>Container Haulage</li>
                <li>Sea Freight</li>
                <li>Warehousing</li>
                <li>Port Services</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Client Portal</h4>
              <p className="text-slate-400 text-sm mb-4">
                Access your account to track containers and manage shipments.
              </p>
              <Button onClick={onGetStarted} variant="outline" className="border-blue-600 text-blue-400 hover:bg-blue-600 hover:text-white">
                Login / Register
              </Button>
            </div>
          </div>
          <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-slate-500 text-sm">
              © 2024 John A Momodu Nigerian Limited. All rights reserved.
            </p>
            <div className="flex gap-6 text-sm text-slate-500">
              <span>Privacy Policy</span>
              <span>Terms of Service</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;
