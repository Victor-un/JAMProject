import React, { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { 
  LayoutDashboard, 
  Container, 
  Plus, 
  LogOut, 
  Search,
  BarChart3,
  Settings,
  Menu
} from 'lucide-react';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import StatsOverview from '@/sections/StatsOverview';
import ContainerList from '@/sections/ContainerList';
import ContainerForm from '@/sections/ContainerForm';
import ContainerDetails from '@/sections/ContainerDetails';
import ReportsSection from '@/sections/ReportsSection';
import type { Container as ContainerType } from '@/types';

type ViewType = 'dashboard' | 'containers' | 'add-container' | 'reports' | 'container-details';

const Dashboard: React.FC = () => {
  const { user, logout } = useAuth();
  const [currentView, setCurrentView] = useState<ViewType>('dashboard');
  const [selectedContainer, setSelectedContainer] = useState<ContainerType | null>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleContainerClick = (container: ContainerType) => {
    setSelectedContainer(container);
    setCurrentView('container-details');
  };

  const handleAddContainer = () => {
    setSelectedContainer(null);
    setCurrentView('add-container');
  };

  const handleEditContainer = (container: ContainerType) => {
    setSelectedContainer(container);
    setCurrentView('add-container');
  };

  const handleBackToList = () => {
    setSelectedContainer(null);
    setCurrentView('containers');
  };

  const renderContent = () => {
    switch (currentView) {
      case 'dashboard':
        return (
          <div className="space-y-6">
            <StatsOverview />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-slate-800">Recent Containers</h3>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setCurrentView('containers')}
                    className="text-blue-600"
                  >
                    View All
                  </Button>
                </div>
                <ContainerList 
                  limit={5} 
                  onContainerClick={handleContainerClick}
                  compact 
                />
              </div>
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-slate-800">Quick Actions</h3>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <Button 
                    onClick={handleAddContainer}
                    className="h-24 flex flex-col items-center justify-center gap-2 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200"
                  >
                    <Plus className="w-6 h-6" />
                    <span>Add Container</span>
                  </Button>
                  <Button 
                    onClick={() => setCurrentView('containers')}
                    className="h-24 flex flex-col items-center justify-center gap-2 bg-green-50 hover:bg-green-100 text-green-700 border border-green-200"
                  >
                    <Search className="w-6 h-6" />
                    <span>Search</span>
                  </Button>
                  <Button 
                    onClick={() => setCurrentView('reports')}
                    className="h-24 flex flex-col items-center justify-center gap-2 bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200"
                  >
                    <BarChart3 className="w-6 h-6" />
                    <span>Reports</span>
                  </Button>
                  <Button 
                    className="h-24 flex flex-col items-center justify-center gap-2 bg-orange-50 hover:bg-orange-100 text-orange-700 border border-orange-200"
                  >
                    <Settings className="w-6 h-6" />
                    <span>Settings</span>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        );
      case 'containers':
        return (
          <ContainerList 
            onContainerClick={handleContainerClick}
            onAddContainer={handleAddContainer}
          />
        );
      case 'add-container':
        return (
          <ContainerForm 
            container={selectedContainer}
            onCancel={handleBackToList}
            onSuccess={handleBackToList}
          />
        );
      case 'container-details':
        return selectedContainer ? (
          <ContainerDetails 
            container={selectedContainer}
            onBack={handleBackToList}
            onEdit={() => handleEditContainer(selectedContainer)}
          />
        ) : null;
      case 'reports':
        return <ReportsSection />;
      default:
        return null;
    }
  };

  const getPageTitle = () => {
    switch (currentView) {
      case 'dashboard': return 'Dashboard';
      case 'containers': return 'Container Management';
      case 'add-container': return selectedContainer ? 'Edit Container' : 'Add New Container';
      case 'container-details': return 'Container Details';
      case 'reports': return 'Reports & Analytics';
      default: return 'Dashboard';
    }
  };

  const NavItems = () => (
    <>
      <Button
        variant={currentView === 'dashboard' ? 'default' : 'ghost'}
        className={`w-full justify-start gap-3 ${currentView === 'dashboard' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:text-slate-900'}`}
        onClick={() => { setCurrentView('dashboard'); setIsMobileMenuOpen(false); }}
      >
        <LayoutDashboard className="w-5 h-5" />
        Dashboard
      </Button>
      <Button
        variant={currentView === 'containers' || currentView === 'add-container' || currentView === 'container-details' ? 'default' : 'ghost'}
        className={`w-full justify-start gap-3 ${currentView === 'containers' || currentView === 'add-container' || currentView === 'container-details' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:text-slate-900'}`}
        onClick={() => { setCurrentView('containers'); setIsMobileMenuOpen(false); }}
      >
        <Container className="w-5 h-5" />
        Containers
      </Button>
      <Button
        variant={currentView === 'reports' ? 'default' : 'ghost'}
        className={`w-full justify-start gap-3 ${currentView === 'reports' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:text-slate-900'}`}
        onClick={() => { setCurrentView('reports'); setIsMobileMenuOpen(false); }}
      >
        <BarChart3 className="w-5 h-5" />
        Reports
      </Button>
    </>
  );

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-64 flex-col bg-white border-r border-slate-200 fixed h-full">
        <div className="p-6 border-b border-slate-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
              <Container className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-slate-800 text-sm leading-tight">John A Momodu</h1>
              <h2 className="font-bold text-slate-800 text-xs">Nigerian Limited</h2>
              <p className="text-[10px] text-slate-500">Container Management</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          <NavItems />
        </nav>

        <div className="p-4 border-t border-slate-200">
          <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg mb-3">
            <Avatar className="w-10 h-10">
              <AvatarFallback className="bg-blue-100 text-blue-700 font-semibold">
                {user?.name?.charAt(0).toUpperCase() || 'U'}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-slate-800 truncate">{user?.name}</p>
              <p className="text-xs text-slate-500 capitalize">{user?.role}</p>
            </div>
          </div>
          <Button 
            variant="outline" 
            className="w-full justify-start gap-3 text-red-600 border-red-200 hover:bg-red-50"
            onClick={logout}
          >
            <LogOut className="w-5 h-5" />
            Sign Out
          </Button>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 bg-white border-b border-slate-200 z-50">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <Container className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="font-bold text-slate-800 text-xs block leading-tight">John A Momodu</span>
              <span className="text-[8px] text-slate-500">Nigerian Limited</span>
            </div>
          </div>
          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="w-6 h-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72">
              <div className="flex flex-col h-full">
                <div className="p-4 border-b border-slate-200">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-10 h-10">
                      <AvatarFallback className="bg-blue-100 text-blue-700 font-semibold">
                        {user?.name?.charAt(0).toUpperCase() || 'U'}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium text-slate-800">{user?.name}</p>
                      <p className="text-xs text-slate-500 capitalize">{user?.role}</p>
                    </div>
                  </div>
                </div>
                <nav className="flex-1 p-4 space-y-2">
                  <NavItems />
                </nav>
                <div className="p-4 border-t border-slate-200">
                  <Button 
                    variant="outline" 
                    className="w-full justify-start gap-3 text-red-600 border-red-200 hover:bg-red-50"
                    onClick={logout}
                  >
                    <LogOut className="w-5 h-5" />
                    Sign Out
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 lg:ml-64 pt-16 lg:pt-0">
        <div className="p-4 lg:p-8">
          {/* Header */}
          <div className="mb-6">
            <h2 className="text-2xl lg:text-3xl font-bold text-slate-800">{getPageTitle()}</h2>
            <p className="text-slate-500 mt-1">
              {currentView === 'dashboard' && 'Overview of your container yard operations'}
              {currentView === 'containers' && 'Manage all container entries and exits'}
              {currentView === 'add-container' && (selectedContainer ? 'Update container information' : 'Register a new container entry')}
              {currentView === 'container-details' && 'View complete container information'}
              {currentView === 'reports' && 'Analytics and performance insights'}
            </p>
          </div>

          {/* Content */}
          {renderContent()}
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
